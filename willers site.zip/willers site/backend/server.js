const express = require('express');
const fs = require('fs');
const path = require('path');
const session = require('express-session');
const app = express();
const PORT = 3000;

app.use(express.static(path.join(__dirname, '../public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: 'supersecretkey',
  resave: false,
  saveUninitialized: true,
}));

const usersPath = path.join(__dirname, '../data/users.json');
const feedbackPath = path.join(__dirname, '../data/feedback.json');
const servicesPath = path.join(__dirname, '../data/services.json');

// Helper to load JSON data safely
function loadData(filePath) {
  if (!fs.existsSync(filePath)) return [];
  try {
    return JSON.parse(fs.readFileSync(filePath));
  } catch (err) {
    console.error('Invalid JSON in:', filePath);
    return [];
  }
}

// Helper to save JSON data
function saveData(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

// Feedback route
app.post('/feedback', (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) return res.status(400).json({ success: false, message: 'Missing fields' });

  const feedbacks = loadData(feedbackPath);
  feedbacks.push({ name, email, message, date: new Date().toISOString() });
  saveData(feedbackPath, feedbacks);
  res.json({ success: true, message: 'Feedback submitted' });
});

// Mowing service route
app.post('/mowing', (req, res) => {
  const { name, address, phone, paymentMethod, lawnSize, notes, discount } = req.body;

  if (!name || !address || !phone || !paymentMethod || !lawnSize) {
    return res.status(400).json({ success: false, message: 'Missing required fields' });
  }

  if (!/^[\d]{10,15}$/.test(phone)) {
    return res.status(400).json({ success: false, message: 'Invalid phone number' });
  }

  const validSizes = ['small', 'normal', 'large', 'xlarge'];
  if (!validSizes.includes(lawnSize)) {
    return res.status(400).json({ success: false, message: 'Invalid lawn size' });
  }

  const validPayments = ['cashapp', 'cash'];
  if (!validPayments.includes(paymentMethod.toLowerCase())) {
    return res.status(400).json({ success: false, message: 'Invalid payment method' });
  }

  const services = loadData(servicesPath);
  services.push({
    type: 'mowing',
    name,
    address,
    phone,
    paymentMethod,
    lawnSize,
    notes: notes || '',
    discount: discount || '',
    date: new Date().toISOString(),
  });
  saveData(servicesPath, services);
  res.json({ success: true, message: 'Mowing service requested' });
});

// API endpoints to send feedback and orders for admin page
app.get('/api/feedback', (req, res) => {
  fs.readFile(feedbackPath, 'utf8', (err, data) => {
    if (err) return res.status(500).json({ error: 'Failed to load feedback' });
    try {
      res.json(JSON.parse(data));
    } catch (err) {
      res.status(500).json({ error: 'Invalid feedback JSON' });
    }
  });
});

app.get('/api/orders', (req, res) => {
  fs.readFile(servicesPath, 'utf8', (err, data) => {
    if (err) return res.status(500).json({ error: 'Failed to load orders' });
    try {
      res.json(JSON.parse(data));
    } catch (err) {
      res.status(500).json({ error: 'Invalid orders JSON' });
    }
  });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
