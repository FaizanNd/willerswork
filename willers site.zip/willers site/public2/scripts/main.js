// Signup form handler
document.getElementById('signup-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const data = {
    username: form.username.value.trim(),
    password: form.password.value.trim(),
  };

  const res = await fetch('/signup', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  form.querySelector('#signup-message').textContent = json.message || 'Error occurred';
});

// Login form handler
document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const data = {
    username: form.username.value.trim(),
    password: form.password.value.trim(),
  };

  const res = await fetch('/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  form.querySelector('#login-message').textContent = json.message || 'Error occurred';
});

// Feedback form handler
document.getElementById('feedback-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const data = {
    name: form.name.value.trim(),
    email: form.email.value.trim(),
    message: form.message.value.trim(),
  };

  const res = await fetch('/feedback', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  form.querySelector('#feedback-message').textContent = json.message || 'Error occurred';
});

// Mowing form handler
document.getElementById('mowing-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;

  const data = {
    name: form.name.value.trim(),
    address: form.address.value.trim(),
    phone: form.phone.value.trim(),
    paymentMethod: form.paymentMethod.value,
    lawnSize: form.lawnSize.value,
    notes: form.notes.value.trim(),
  };

  const res = await fetch('/mowing', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

  const json = await res.json();
  form.querySelector('#mowing-message').textContent = json.message || 'Error occurred';
});

